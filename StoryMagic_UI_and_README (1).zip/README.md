# 📚 StoryMagic: AI-Powered Animated Storytelling App

StoryMagic is a cross-platform app built with **React Native (Expo)** and **FastAPI** that allows users to:
- Generate illustrated stories using GPT-4 + DALL·E
- Narrate stories with gTTS (Google Text-to-Speech)
- Export stories as videos
- Save stories via Firebase Auth + Firestore

---

## 🚀 Features

- ✍️ AI-written stories (OpenAI GPT-4)
- 🎨 AI-generated images (DALL·E)
- 🔊 Narration with gTTS
- 🎬 Export to MP4 video
- 🔐 Firebase Authentication (Login/Signup)
- 💾 Save and view story history

---

## 🧩 Technologies

| Stack       | Tools                            |
|-------------|----------------------------------|
| Frontend    | React Native + Expo              |
| Backend     | FastAPI + OpenAI + gTTS + moviepy|
| Storage     | Firebase Firestore               |
| Hosting     | Render (backend), Firebase (web) |

---

## 🛠️ Setup Instructions

### 1. Clone the repo

```bash
git clone https://github.com/yourusername/storymagic.git
cd storymagic
```

### 2. Backend (FastAPI)

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

- Add `.env` with:
  ```
  OPENAI_API_KEY=your-api-key
  ```

To deploy, push to GitHub and connect to [https://render.com](https://render.com)

---

### 3. Frontend (Expo)

```bash
cd frontend
npm install
npx expo start
```

Update `firebase.js` with your project config.

To export for web:
```bash
npx expo export:web
firebase deploy
```

---

## ✨ Firebase Setup

- Enable **Authentication** (Email/Password)
- Create a **Firestore** database
- Stories are saved to:
  ```
  users/{uid}/stories/{timestamp}
  ```

---

## 📂 Project Structure

```
StoryMagic/
├── backend/
│   ├── main.py
│   ├── requirements.txt
│   └── render.yaml
├── frontend/
│   ├── App.js
│   ├── firebase.js
│   ├── screens/
│   │   ├── LoginScreen.js
│   │   ├── SignupScreen.js
│   │   └── StoryHistoryScreen.js
└── README.md
```

---

Made with ❤️ using OpenAI, Firebase, and Expo.
