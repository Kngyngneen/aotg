import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView } from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { auth, db } from '../firebase';

export default function StoryHistoryScreen() {
  const [stories, setStories] = useState([]);

  useEffect(() => {
    const loadStories = async () => {
      const uid = auth.currentUser?.uid;
      if (!uid) return;
      const ref = collection(db, "users", uid, "stories");
      const snapshot = await getDocs(ref);
      const data = snapshot.docs.map(doc => doc.data());
      setStories(data);
    };

    loadStories();
  }, []);

  return (
    <ScrollView style={{ padding: 20 }}>
      {stories.map((story, index) => (
        <View key={index} style={{ marginBottom: 20 }}>
          <Text style={{ fontWeight: 'bold' }}>{story.prompt}</Text>
          <Text numberOfLines={3}>{story.story}</Text>
        </View>
      ))}
    </ScrollView>
  );
}
